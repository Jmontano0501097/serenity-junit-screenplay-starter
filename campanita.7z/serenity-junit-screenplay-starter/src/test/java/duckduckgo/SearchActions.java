package duckduckgo;

import net.serenitybdd.core.pages.PageComponent;
import net.serenitybdd.core.steps.UIInteractions;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;

public class SearchActions extends UIInteractions {
    @Step("Search for '{0}'")
    public void byKeyword(String keyword){
        $("#search_form_input_homepage").sendKeys(keyword);
        $(".search__button").click();
    }
}

